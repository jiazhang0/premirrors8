
The build tools are generally tools written in java that are used to build
the jdk or provide help in working with the jdk.

They are all built with the BOOTDIR javac and run with the BOOTDIR java.

They need only be built once.

