RSpec.configure do |config|
  config.alias_it_should_behave_like_to :example_behavior_for, "parses"
end
