{
  :pre_suite => [
    'setup/common/00_EnvSetup.rb',
    'setup/git/pre-suite/01_TestSetup.rb',
  ],
}
