require 'puppet/application/face_base'

class Puppet::Application::Module < Puppet::Application::FaceBase
end
