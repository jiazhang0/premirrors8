require 'puppet/application/indirection_base'

class Puppet::Application::File < Puppet::Application::IndirectionBase
end
