# A stub class, so our constants work.
class Puppet::Indirector::InstrumentationProbe
end
